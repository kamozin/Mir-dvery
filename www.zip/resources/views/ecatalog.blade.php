<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>������� ��������� "��� ������", �. ������</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <script type="text/javascript" src="files/swfobject.js">//</script>
    <script type="text/javascript" src="files/swfaddress.js">//</script>
    <script type="text/javascript" src="files/facebook.js">//</script>
    <script type="text/javascript">
        var assetsFolder = 'assets';
        var mobileFolder = 'mobile';
        var filesFolderName	 = 'files';
        var projectGUID = 'c8ced824161b933f0a723f785cef9b4b';
        var documentBackColor = 'DEDEDE';</script>
    <script type="text/javascript" src="files/fbscript.js">//</script>
    <style type="text/css">
        html {
            width :100%;
            height:100%;
        }</style>
</head>
<body style="padding: 0px; margin: 0px; height:100%; width:100%; background-color:#DEDEDE"><!--
          ProductVersion=2.3.14--><!--
          FBID=af96a9a53a2c352d4a207ecc5cc59c5e--><div id="content">
    <h1>Alternative content</h1>
    <p>
        <a href="http://www.adobe.com/go/getflashplayer">
            <img src="" id="getFlashIMG" alt="Get Adobe Flash player" />
        </a>
        <br />
        <a id="hrefMobile" href="files/mobile/index.html">
            Mobile version
        </a>
        <br />
        <a id="hrefSEO" href="files/assets/basic-html/toc.html">
            Basic HTML version
        </a>
    </p>
</div>
</body>
</html>