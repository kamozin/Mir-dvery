<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">Страницы</div>

                    <div class="panel-body">
                        <?php /*<a href="/admin/category/store" class="btn btn-primary">Добавить страницу</a>*/ ?>
                    </div>
                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success alert-dismissible fade in" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                            </button>
                            <strong><?php echo e(session()->get('success')); ?></strong>
                        </div>
                    <?php endif; ?>
                    <div class="panel-body">
                        <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap"
                               cellspacing="0"
                               width="100%">
                            <thead>
                            <tr>
                                <th>№ п/п</th>
                                <th>Наименование страницы</th>
                                <th>Description</th>
                                <th>Keywords</th>
                                <th>Title</th>
                                <th>Редактировать</th>
                                <th>Удалить</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach($page as $p): ?>
                                <tr>
                                    <td><?php echo e($p->id); ?></td>
                                    <td>
                                        <?php echo e($p->name); ?>

                                    </td>
                                    <td>
                                       <?php echo e($p->description); ?>

                                    </td>
                                    <td>
                                       <?php echo e($p->keywords); ?>

                                    </td>
                                    <td>
                                       <?php echo e($p->title); ?>

                                    </td>
                                    <td><a href="/admin/page/edit/<?php echo e($p->id); ?>">Редактировать</a></td>
                                    <td><a href="/admin/page/destroy/<?php echo e($p->id); ?>">Удалить</a></td>

                                </tr>
                            <?php endforeach; ?>

                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>

    <link href="/includes/admin/js/datatables/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <script src="/includes/admin/js/datatables/jquery.dataTables.min.js"></script>
    <script>

        $('#datatable-responsive').DataTable({

            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.12/i18n/Russian.json"
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>