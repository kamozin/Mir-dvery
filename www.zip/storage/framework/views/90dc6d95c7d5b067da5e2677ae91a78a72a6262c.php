<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">Акции</div>

                    <div class="panel-body">
                        <a href="/admin/directory/characteristics/<?php echo e($id); ?>/store" class="btn btn-primary">Добавить
                            характеристику</a>
                    </div>
                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success alert-dismissible fade in" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                        aria-hidden="true">×</span>
                            </button>
                            <strong><?php echo e(session()->get('success')); ?></strong>
                        </div>
                    <?php endif; ?>
                    <div class="panel-body">
                        <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap"
                               cellspacing="0"
                               width="100%">
                            <thead>
                            <tr>
                                <th>№ п/п</th>
                                <th>фото</th>
                                <th>Название</th>
                                <th>Справочник</th>
                                <th>Раздел</th>
                                <th>Редактировать</th>
                                <th>Удалить</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach($har as $h): ?>
                                <tr>
                                    <td><?php echo e($h->id); ?></td>
                                    <td>
                                        <img src="/gallery/directory/<?php echo e($h->img); ?>" width="70" height="70">
                                    </td>
                                    <td>
                                        <?php echo e($h->name); ?>

                                    </td>
                                    <td>
                                        <?php foreach($directory as $d): ?>
                                            <?php if($d->id==$h->id_directory): ?>
                                                <?php echo e($d->name); ?>

                                            <?php endif; ?>

                                        <?php endforeach; ?>
                                    </td>
                                    <td>

                                        <?php foreach($directory as $d): ?>
                                            <?php if($d->id==$h->id_razdel): ?>
                                                <?php echo e($d->name); ?>

                                            <?php endif; ?>

                                        <?php endforeach; ?>

                                    </td>

                                    <td><a href="/admin/actions/edit/<?php echo e($h->id); ?>">Редактировать</a></td>
                                    <td><a href="/admin/actions/destroy/<?php echo e($h->id); ?>">Удалить</a></td>

                                </tr>
                            <?php endforeach; ?>

                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>

    <link href="/includes/admin/js/datatables/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <script src="/includes/admin/js/datatables/jquery.dataTables.min.js"></script>
    <script>

        $('#datatable-responsive').DataTable({

            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.12/i18n/Russian.json"
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>