<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">Акции</div>

                    <div class="panel-body">
                        <a href="/admin/directory/store" class="btn btn-primary">Добавить справочник/раздел</a>
                    </div>
                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success alert-dismissible fade in" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                            </button>
                            <strong><?php echo e(session()->get('success')); ?></strong>
                        </div>
                    <?php endif; ?>
                    <div class="panel-body">
                        <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap"
                               cellspacing="0"
                               width="100%">
                            <thead>
                            <tr>
                                <th>№ п/п</th>
                                <th>Наименование справочнка или раздела</th>
                                <th>Справочник</th>
                                <th>Характеристики</th>
                                <th>Редактировать</th>
                                <th>Удалить</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach($directory as $d): ?>
                                <tr>
                                    <td><?php echo e($d->id); ?></td>
                                    <td>
                                        <?php echo e($d->name); ?>

                                    </td>
                                    <td>
                                        <?php if($d->parent_id==0): ?>
                                        Справочник
                                            <?php else: ?>
                                            <?php foreach($directory as $dir): ?>

                                                <?php if($dir->id==$d->parent_id): ?>

                                                    <?php echo e($dir->name); ?>


                                                    <?php endif; ?>
                                                <?php endforeach; ?>

                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($d->parent_id==0): ?>
                                            Характеристики доступны только в разделе справочника
                                            <?php else: ?>
                                        <a href="/admin/directory/characteristics/<?php echo e($d->id); ?>">Характеристики</a>
                                            <?php endif; ?>
                                    </td>
                                    <td><a href="/admin/actions/edit/<?php echo e($d->id); ?>">Редактировать</a></td>
                                    <td><a href="/admin/actions/destroy/<?php echo e($d->id); ?>">Удалить</a></td>

                                </tr>
                            <?php endforeach; ?>

                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>

    <link href="/includes/admin/js/datatables/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <script src="/includes/admin/js/datatables/jquery.dataTables.min.js"></script>
    <script>

        $('#datatable-responsive').DataTable({

            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.12/i18n/Russian.json"
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>