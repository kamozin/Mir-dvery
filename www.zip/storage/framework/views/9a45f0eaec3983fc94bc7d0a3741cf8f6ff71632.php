<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">Категории</div>

                    <div class="panel-body">
                        <a href="/admin/category/store" class="btn btn-primary">Добавить категорию</a>
                    </div>
                    <?php if(session()->has('success')): ?>
                    <div class="alert alert-success alert-dismissible fade in" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                        </button>
                        <strong><?php echo e(session()->get('success')); ?></strong>
                    </div>
                    <?php endif; ?>
                    <div class="panel-body">
                        <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap"
                               cellspacing="0"
                               width="100%">
                            <thead>
                            <tr>
                                <th>№ п/п</th>
                                <th>Наименование категории</th>
                                <th>Категория родитель</th>
                                <th>Редактировать</th>
                                <th>Обновить фото категории</th>
                                <th>Удалить</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach($category as $c): ?>
                                <tr>
                                    <td><?php echo e($c->id); ?></td>
                                    <td>
                                        <?php echo e($c->name); ?>

                                    </td>
                                    <td>
                                        <?php if($c->parent_id==0): ?>
                                            Категория родитель
                                        <?php else: ?>
                                            <?php foreach($category as $cat): ?>

                                                <?php if($c->parent_id==$cat->id): ?>
                                                    <?php echo e($cat->name); ?>


                                                <?php endif; ?>
                                            <?php endforeach; ?>

                                        <?php endif; ?>
                                    </td>
                                    <td><a href="/admin/category/edit/<?php echo e($c->id); ?>">Редактировать</a></td>
                                    <td><a href="/admin/category/photo/<?php echo e($c->id); ?>">Обновить фото</a></td>
                                    <td><a href="/admin/category/destroy/<?php echo e($c->id); ?>">Удалить</a></td>

                                </tr>
                            <?php endforeach; ?>

                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>

    <link href="/includes/admin/js/datatables/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <script src="/includes/admin/js/datatables/jquery.dataTables.min.js"></script>
    <script>

        $('#datatable-responsive').DataTable({

            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.12/i18n/Russian.json"
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>