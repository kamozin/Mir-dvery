<?php $__env->startSection('header'); ?>

    <link rel="stylesheet" type="text/css" href="/includes/css/magnific-popup.css">
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="content">
        <h1><?php echo e($page['name']); ?></h1>
<?php echo $page['text']; ?>

    </div>

    <?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <script type="text/javascript" src="/includes/js/jquery.magnific-popup.js"></script>
    <script type="text/javascript" src="/includes/js/jquery.magnific-popup.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.zoom-gallery').magnificPopup({
                delegate: 'a',
                type: 'image',
                closeOnContentClick: false,
                closeBtnInside: false,
                mainClass: 'mfp-with-zoom mfp-img-mobile',
                image: {
                    verticalFit: true,
                    // titleSrc: function(item) {
                    // 	return item.el.attr('title') + ' &middot; <a class="image-source-link" href="'+item.el.attr('data-source')+'" target="_blank">image source</a>';
                    // }
                },
                gallery: {
                    enabled: true
                },
                zoom: {
                    enabled: true,
                    duration: 300, // don't foget to change the duration also in CSS
                    opener: function(element) {
                        return element.find('img');
                    }
                }

            });
        });
    </script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>